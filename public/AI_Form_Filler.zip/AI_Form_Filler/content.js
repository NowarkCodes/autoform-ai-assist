// content.js - FIXED Profile Data Handling
console.log('🤖 Auto Form Filler - FIXED PROFILE DATA VERSION');

class FormFiller {
  constructor() {
    this.userProfile = {};
    this.debugMode = true;
    this.init();
  }
  
  async init() {
    this.log('🚀 Initializing FormFiller - Profile Data Fixed');
    
    // Get profile with better error handling
    this.userProfile = await this.getUserProfile();
    this.log('📝 User profile loaded:', this.userProfile);
    
    // Validate profile data
    if (!this.userProfile || typeof this.userProfile !== 'object') {
      this.log('⚠️ No valid profile data found, checking storage...');
      await this.debugProfileStorage();
    } else {
      this.log('✅ Profile data is valid');
    }
    
    setTimeout(() => {
      this.scanForForms();
      this.observePageChanges();
    }, 1000);
  }
  
  log(message, data = null) {
    if (this.debugMode) {
      console.log(`[FormFiller-PROFILE-FIXED] ${message}`, data || '');
    }
  }
  
  async getUserProfile() {
    return new Promise((resolve) => {
      this.log('🔄 Requesting profile from background...');
      
      chrome.runtime.sendMessage({ action: 'getProfile' }, (response) => {
        if (chrome.runtime.lastError) {
          this.log('❌ Runtime error getting profile:', chrome.runtime.lastError);
          resolve({});
          return;
        }
        
        this.log('📦 Profile response received:', response);
        
        // Handle different response formats
        if (response && typeof response === 'object') {
          // Check if it's a valid profile object
          const hasValidData = response.name || response.email || response.phone || 
                              response.company || response.position || response.address;
          
          if (hasValidData) {
            this.log('✅ Valid profile data found');
            resolve(response);
          } else {
            this.log('⚠️ Empty profile data received');
            resolve({});
          }
        } else {
          this.log('⚠️ Invalid profile response format');
          resolve({});
        }
      });
    });
  }
  
  async debugProfileStorage() {
    this.log('🔍 Debugging profile storage...');
    
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({ action: 'debugStorage' }, (allData) => {
        this.log('🗂️ All storage data:', allData);
        
        // Try to find profile data anywhere in storage
        if (allData && allData.userProfile) {
          this.log('✅ Found userProfile in storage:', allData.userProfile);
          this.userProfile = allData.userProfile;
        } else {
          this.log('❌ No userProfile found in storage');
        }
        
        resolve();
      });
    });
  }
  
  scanForForms() {
    const inputs = document.querySelectorAll('input[type="text"], input[type="email"], input[type="tel"], input[type="url"], textarea, input:not([type])');
    this.log(`🔍 Found ${inputs.length} fillable inputs`);
    
    inputs.forEach((input, index) => {
      const fieldType = this.detectFieldType(input);
      const isProfile = this.isBasicProfileField(fieldType);
      const isAI = this.shouldUseAI(fieldType);
      
      this.log(`📝 Input ${index + 1}:`, {
        element: input.tagName.toLowerCase(),
        type: input.type || 'text',
        name: input.name,
        placeholder: input.placeholder,
        detectedAs: fieldType,
        isProfile: isProfile,
        isAI: isAI,
        hasProfileData: isProfile ? !!this.getStoredValue(fieldType) : 'N/A'
      });
      
      this.addAutoFillButton(input);
    });
  }
  
  addAutoFillButton(input) {
    if (input.type === 'hidden' || 
        input.type === 'submit' || 
        input.type === 'button' ||
        input.type === 'checkbox' ||
        input.type === 'radio' ||
        input.style.display === 'none' ||
        input.parentElement.querySelector('.auto-fill-btn')) {
      return;
    }
    
    const button = document.createElement('button');
    button.className = 'auto-fill-btn';
    button.innerHTML = '🤖';
    button.title = 'Auto fill this field';
    button.type = 'button';
    
    button.style.cssText = `
      position: absolute !important;
      right: 8px !important;
      top: 50% !important;
      transform: translateY(-50%) !important;
      background: #4285f4 !important;
      color: white !important;
      border: none !important;
      border-radius: 4px !important;
      width: 28px !important;
      height: 28px !important;
      font-size: 14px !important;
      cursor: pointer !important;
      z-index: 10000 !important;
      display: none !important;
      box-shadow: 0 2px 5px rgba(0,0,0,0.2) !important;
    `;
    
    const parent = input.parentElement;
    const parentStyle = window.getComputedStyle(parent);
    if (parentStyle.position === 'static') {
      parent.style.position = 'relative';
    }
    
    const showButton = () => button.style.display = 'block';
    const hideButton = () => setTimeout(() => button.style.display = 'none', 200);
    
    input.addEventListener('focus', showButton);
    input.addEventListener('mouseenter', showButton);
    input.addEventListener('blur', hideButton);
    input.addEventListener('mouseleave', hideButton);
    button.addEventListener('mouseenter', () => button.style.display = 'block');
    
    button.addEventListener('click', async (e) => {
      e.preventDefault();
      e.stopPropagation();
      
      this.log('🖱️ Button clicked for field:', input.name || input.placeholder);
      
      button.innerHTML = '⏳';
      button.style.background = '#ff9800';
      
      try {
        await this.fillField(input);
        
        button.innerHTML = '✅';
        button.style.background = '#4caf50';
        
        setTimeout(() => {
          button.innerHTML = '🤖';
          button.style.background = '#4285f4';
        }, 1500);
        
      } catch (error) {
        this.log('❌ Error filling field:', error);
        
        button.innerHTML = '❌';
        button.style.background = '#f44336';
        
        setTimeout(() => {
          button.innerHTML = '🤖';
          button.style.background = '#4285f4';
        }, 1500);
      }
    });
    
    parent.appendChild(button);
  }
  
  async fillField(input) {
    const fieldType = this.detectFieldType(input);
    this.log('🔄 Filling field - Type:', fieldType);
    
    if (this.isBasicProfileField(fieldType)) {
      this.log('👤 Using PROFILE data for:', fieldType);
      this.log('📋 Current profile data:', this.userProfile);
      
      const storedValue = this.getStoredValue(fieldType);
      this.log('💾 Retrieved stored value:', storedValue || 'EMPTY');
      
      if (storedValue && storedValue.trim()) {
        this.log('✅ Using profile value:', storedValue);
        this.setInputValue(input, storedValue);
        return;
      } else {
        // Try to refresh profile data
        this.log('🔄 No stored value found, refreshing profile...');
        this.userProfile = await this.getUserProfile();
        
        const refreshedValue = this.getStoredValue(fieldType);
        if (refreshedValue && refreshedValue.trim()) {
          this.log('✅ Using refreshed profile value:', refreshedValue);
          this.setInputValue(input, refreshedValue);
          return;
        } else {
          throw new Error(`No profile data saved for ${fieldType}. Please fill your profile in the extension options.`);
        }
      }
    } 
    else if (this.shouldUseAI(fieldType)) {
      this.log('🤖 Using AI generation for:', fieldType);
      
      try {
        const context = this.getFieldContext(input);
        const response = await chrome.runtime.sendMessage({
          action: 'generateAISuggestion',
          fieldType,
          context
        });
        
        if (chrome.runtime.lastError) {
          throw new Error(chrome.runtime.lastError.message);
        }
        
        if (response && response.suggestion) {
          this.log('✨ AI suggestion received');
          this.setInputValue(input, response.suggestion);
          return;
        }
        
        if (response && response.error) {
          throw new Error(response.error);
        }
        
        throw new Error('No AI response received');
        
      } catch (error) {
        this.log('🚫 AI failed, using generic:', error.message);
        const genericValue = this.getGenericValue(fieldType);
        if (genericValue) {
          this.setInputValue(input, genericValue);
        } else {
          throw error;
        }
      }
    } 
    else {
      this.log('❓ Unknown field type, using generic');
      const genericValue = this.getGenericValue('general');
      this.setInputValue(input, genericValue);
    }
  }
  
  detectFieldType(input) {
    const name = (input.name || '').toLowerCase();
    const placeholder = (input.placeholder || '').toLowerCase();
    const id = (input.id || '').toLowerCase(); 
    const label = this.getFieldLabel(input)?.toLowerCase() || '';
    const tagName = input.tagName.toLowerCase();
    const inputType = (input.type || 'text').toLowerCase();
    
    const allText = `${name} ${placeholder} ${id} ${label}`;
    
    // Input type-based detection
    if (inputType === 'email') return 'email';
    if (inputType === 'tel') return 'phone';
    if (inputType === 'url') return 'linkedin';
    
    // Exact keyword matching
    if (this.containsExactKeyword(allText, ['email', 'e-mail', 'mail'])) return 'email';
    if (this.containsExactKeyword(allText, ['phone', 'mobile', 'tel', 'telephone', 'contact number'])) return 'phone';
    
    // Bio detection (before name)
    if (this.isBioField(allText, tagName)) return 'bio';
    
    // Name detection  
    if (this.isNameField(allText) && !this.isBioField(allText, tagName)) return 'name';
    
    // Other AI fields
    if (this.isMessageField(allText)) return 'message';
    if (this.isReasonField(allText)) return 'reason';
    
    // Other profile fields
    if (this.containsExactKeyword(allText, ['company', 'organization', 'employer', 'workplace'])) return 'company';
    if (this.containsExactKeyword(allText, ['position', 'job title', 'title', 'role', 'occupation'])) return 'position';
    if (this.containsExactKeyword(allText, ['address', 'street', 'location', 'city', 'zip'])) return 'address';
    if (this.containsExactKeyword(allText, ['linkedin', 'profile url', 'social profile'])) return 'linkedin';
    
    // Experience and descriptions
    if (this.containsExactKeyword(allText, ['experience', 'background', 'history'])) return 'experience';
    if (this.containsExactKeyword(allText, ['description', 'describe', 'details'])) return 'description';
    
    // Textarea fallback
    if (tagName === 'textarea' && allText.length > 5) return 'general_ai';
    
    return 'general';
  }
  
  containsExactKeyword(text, keywords) {
    return keywords.some(keyword => {
      const regex = new RegExp(`\\b${keyword}\\b`, 'i');
      return regex.test(text);
    });
  }
  
  isBioField(text, tagName) {
    const bioKeywords = [
      'bio', 'about', 'about me', 'about yourself', 'about you',
      'profile', 'introduction', 'personal statement', 'summary',
      'tell us about', 'describe yourself', 'personal info',
      'professional summary', 'cover letter'
    ];
    
    return this.containsExactKeyword(text, bioKeywords);
  }
  
  isNameField(text) {
    const nameKeywords = ['full name', 'fullname', 'first name', 'last name', 'your name'];
    return this.containsExactKeyword(text, nameKeywords) ||
           (text.includes('name') && 
            !text.includes('username') && 
            !text.includes('filename') &&
            !text.includes('company') &&
            !text.includes('domain'));
  }
  
  isMessageField(text) {
    const messageKeywords = [
      'message', 'comment', 'comments', 'additional', 'note', 'notes',
      'remarks', 'feedback', 'thoughts', 'anything else', 'other'
    ];
    return this.containsExactKeyword(text, messageKeywords);
  }
  
  isReasonField(text) {
    const reasonKeywords = [
      'reason', 'why', 'motivation', 'interested', 'apply',
      'motivate', 'inspire', 'purpose', 'because', 'goal'
    ];
    return this.containsExactKeyword(text, reasonKeywords);
  }
  
  isBasicProfileField(fieldType) {
    const basicFields = ['name', 'email', 'phone', 'address', 'company', 'position', 'linkedin'];
    return basicFields.includes(fieldType);
  }
  
  shouldUseAI(fieldType) {
    const aiFields = ['bio', 'message', 'reason', 'experience', 'description', 'objective', 'general_ai'];
    return aiFields.includes(fieldType);
  }
  
  getFieldLabel(input) {
    if (input.id) {
      const label = document.querySelector(`label[for="${input.id}"]`);
      if (label) return label.textContent.trim();
    }
    
    const parentLabel = input.closest('label');
    if (parentLabel) return parentLabel.textContent.trim();
    
    let prev = input.previousElementSibling;
    while (prev) {
      if (prev.tagName === 'LABEL') {
        return prev.textContent.trim();
      }
      prev = prev.previousElementSibling;
    }
    
    return '';
  }
  
  getFieldContext(input) {
    const pageTitle = document.title;
    const label = this.getFieldLabel(input);
    const fieldType = this.detectFieldType(input);
    
    return `Page: ${pageTitle}, Label: ${label}, Field: ${fieldType}`.substring(0, 200);
  }
  
  getStoredValue(fieldType) {
    const profile = this.userProfile;
    
    this.log('🔍 Getting stored value for:', fieldType);
    this.log('📋 From profile:', profile);
    
    if (!profile || typeof profile !== 'object') {
      this.log('⚠️ No valid profile object');
      return '';
    }
    
    let value = '';
    
    switch (fieldType) {
      case 'name': 
        value = profile.name || '';
        break;
      case 'email': 
        value = profile.email || '';
        break;
      case 'phone': 
        value = profile.phone || '';
        break;
      case 'address': 
        value = profile.address || '';
        break;
      case 'company': 
        value = profile.company || '';
        break;
      case 'position': 
        value = profile.position || '';
        break;
      case 'linkedin': 
        value = profile.linkedin || '';
        break;
      default: 
        this.log('⚠️ No mapping for field type:', fieldType);
        value = '';
    }
    
    this.log(`📤 Stored value for ${fieldType}:`, value || 'EMPTY');
    return value;
  }
  
  getGenericValue(fieldType) {
    const genericValues = {
      bio: 'I am a dedicated professional with a passion for excellence and continuous learning. I enjoy tackling challenging projects and collaborating with diverse teams to achieve outstanding results.',
      message: 'Thank you for considering my application. I look forward to the opportunity to discuss how I can contribute to your organization.',
      reason: 'I am genuinely interested in this opportunity because it aligns with my professional goals and allows me to utilize my skills effectively.',
      experience: 'I have gained valuable experience through various projects and roles, developing strong analytical and problem-solving skills.',
      description: 'This represents an innovative approach combining best practices with creative solutions.',
      general_ai: 'I am excited about this opportunity and believe my background makes me a strong candidate.',
      general: 'Please see my profile for additional details.'
    };
    
    return genericValues[fieldType] || genericValues.general;
  }
  
  setInputValue(input, value) {
    this.log('📝 Setting input value:', value.substring(0, 50) + (value.length > 50 ? '...' : ''));
    
    input.focus();
    input.value = '';
    input.value = value;
    
    const events = ['input', 'change', 'keyup', 'blur'];
    events.forEach(eventType => {
      const event = new Event(eventType, { bubbles: true });
      input.dispatchEvent(event);
    });
    
    // React compatibility
    try {
      const descriptor = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value');
      descriptor.set.call(input, value);
      input.dispatchEvent(new Event('input', { bubbles: true }));
    } catch (e) {
      // Ignore
    }
    
    this.log('✅ Value set successfully');
  }
  
  // Communication methods
  countForms() {
    const forms = document.querySelectorAll('form');
    const inputs = document.querySelectorAll('input[type="text"], input[type="email"], input[type="tel"], textarea, input:not([type])');
    return {
      forms: forms.length,
      inputs: inputs.length,
      total: Math.max(forms.length, inputs.length > 0 ? 1 : 0)
    };
  }
  
  async fillAllForms() {
    const inputs = document.querySelectorAll('input[type="text"], input[type="email"], input[type="tel"], textarea, input:not([type])');
    let filledCount = 0;
    
    for (let input of inputs) {
      try {
        if (input.value.trim() === '' && input.type !== 'hidden') {
          await this.fillField(input);
          filledCount++;
          await new Promise(resolve => setTimeout(resolve, 300));
        }
      } catch (error) {
        this.log('❌ Error filling field:', error);
      }
    }
    
    return { filled: filledCount, total: inputs.length };
  }
  
  clearAllFields() {
    const inputs = document.querySelectorAll('input[type="text"], input[type="email"], input[type="tel"], textarea, input:not([type])');
    inputs.forEach(input => {
      if (input.type !== 'hidden') {
        this.setInputValue(input, '');
      }
    });
    return { cleared: inputs.length };
  }
  
  observePageChanges() {
    const observer = new MutationObserver((mutations) => {
      let shouldRescan = false;
      
      mutations.forEach((mutation) => {
        mutation.addedNodes.forEach((node) => {
          if (node.nodeType === Node.ELEMENT_NODE) {
            if (node.tagName === 'FORM' || node.tagName === 'INPUT' || node.tagName === 'TEXTAREA') {
              shouldRescan = true;
            } else if (node.querySelector && (node.querySelector('form') || node.querySelector('input') || node.querySelector('textarea'))) {
              shouldRescan = true;
            }
          }
        });
      });
      
      if (shouldRescan) {
        this.log('🔄 Page changed, rescanning...');
        setTimeout(() => this.scanForForms(), 500);
      }
    });
    
    observer.observe(document.body, {
      childList: true,
      subtree: true
    });
  }
}

// Message listener
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (!window.formFillerInstance) {
    window.formFillerInstance = new FormFiller();
  }
  
  const filler = window.formFillerInstance;
  
  switch (request.action) {
    case 'countForms':
      const count = filler.countForms();
      sendResponse({ count: count.total });
      break;
      
    case 'fillAllForms':
      filler.fillAllForms()
        .then(result => sendResponse({ success: true, result }))
        .catch(error => sendResponse({ success: false, error: error.message }));
      return true;
      
    case 'clearAllFields':
      const clearResult = filler.clearAllFields();
      sendResponse({ success: true, result: clearResult });
      break;
      
    default:
      sendResponse({ error: 'Unknown action' });
  }
});

// Initialize
const initFormFiller = () => {
  console.log('🎯 Initializing PROFILE-FIXED FormFiller...');
  window.formFillerInstance = new FormFiller();
};

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initFormFiller);
} else {
  initFormFiller();
}