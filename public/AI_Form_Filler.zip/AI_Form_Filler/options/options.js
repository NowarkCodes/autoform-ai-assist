// options.js - Fixed profile saving and bio field detection
document.addEventListener('DOMContentLoaded', () => {
  console.log('🎯 Options page loaded - Fixed version');
  const options = new OptionsController();
  options.init();
});

class OptionsController {
  constructor() {
    // Profile form and fields
    this.profileForm = document.getElementById('profileForm');
    this.nameField = document.getElementById('name');
    this.emailField = document.getElementById('email');
    this.phoneField = document.getElementById('phone');
    this.addressField = document.getElementById('address');
    this.companyField = document.getElementById('company');
    this.positionField = document.getElementById('position');
    this.linkedinField = document.getElementById('linkedin');
    
    // AI form and fields
    this.aiForm = document.getElementById('aiForm');
    this.aiEnabledField = document.getElementById('aiEnabled');
    this.aiProviderField = document.getElementById('aiProvider');
    this.groqKeyField = document.getElementById('groqKey');
    this.geminiKeyField = document.getElementById('geminiKey');
    this.openaiKeyField = document.getElementById('openaiKey');
    
    // Buttons and status
    this.testConnectionBtn = document.getElementById('testConnection');
    this.status = document.getElementById('status');
    
    console.log('📋 DOM elements check:', {
      profileForm: !!this.profileForm,
      nameField: !!this.nameField,
      aiForm: !!this.aiForm,
      aiEnabledField: !!this.aiEnabledField
    });
  }
  
  async init() {
    await this.loadSettings();
    this.bindEvents();
    this.updateProviderVisibility();
    
    // Add save buttons if they don't exist or aren't working
    this.ensureSaveButtons();
  }
  
  ensureSaveButtons() {
    // Make sure save buttons work properly
    const profileSaveBtn = document.querySelector('#profileForm button[type="submit"], #profileForm .btn-primary');
    const aiSaveBtn = document.querySelector('#aiForm button[type="submit"], #aiForm .btn-primary');
    
    if (profileSaveBtn) {
      console.log('👤 Profile save button found');
      profileSaveBtn.addEventListener('click', (e) => {
        e.preventDefault();
        console.log('💾 Profile save button clicked');
        this.saveProfile();
      });
    } else {
      console.warn('⚠️ Profile save button not found');
    }
    
    if (aiSaveBtn) {
      console.log('🤖 AI save button found');
      aiSaveBtn.addEventListener('click', (e) => {
        e.preventDefault();
        console.log('💾 AI save button clicked');
        this.saveAISettings();
      });
    } else {
      console.warn('⚠️ AI save button not found');
    }
  }
  
  async loadSettings() {
    try {
      console.log('📥 Loading settings...');
      
      // Load profile data with better error handling
      const profileData = await this.getStorageData('userProfile');
      console.log('👤 Raw profile data from storage:', profileData);
      
      // Handle different storage formats
      let profile = {};
      if (profileData && profileData.userProfile) {
        profile = profileData.userProfile;
      } else if (profileData && typeof profileData === 'object') {
        // Check if profileData itself contains profile fields
        if (profileData.name || profileData.email || profileData.phone) {
          profile = profileData;
        }
      }
      
      console.log('👤 Processed profile data:', profile);
      
      // Set profile fields with safety checks
      if (this.nameField) this.nameField.value = profile.name || '';
      if (this.emailField) this.emailField.value = profile.email || '';
      if (this.phoneField) this.phoneField.value = profile.phone || '';
      if (this.addressField) this.addressField.value = profile.address || '';
      if (this.companyField) this.companyField.value = profile.company || '';
      if (this.positionField) this.positionField.value = profile.position || '';
      if (this.linkedinField) this.linkedinField.value = profile.linkedin || '';
      
      // Load AI settings
      const aiData = await this.getStorageData('aiSettings');
      console.log('🤖 Raw AI data from storage:', aiData);
      
      let aiSettings = {};
      if (aiData && aiData.aiSettings) {
        aiSettings = aiData.aiSettings;
      } else if (aiData && typeof aiData === 'object') {
        aiSettings = aiData;
      }
      
      console.log('🤖 Processed AI settings:', aiSettings);
      
      // Set AI fields with safety checks
      if (this.aiEnabledField) this.aiEnabledField.checked = aiSettings.enabled || false;
      if (this.aiProviderField) this.aiProviderField.value = aiSettings.provider || 'groq';
      if (this.groqKeyField) this.groqKeyField.value = aiSettings.groqKey || '';
      if (this.geminiKeyField) this.geminiKeyField.value = aiSettings.geminiKey || '';
      if (this.openaiKeyField) this.openaiKeyField.value = aiSettings.openaiKey || '';
      
      console.log('✅ All settings loaded successfully');
      
    } catch (error) {
      console.error('❌ Failed to load settings:', error);
      this.showStatus('Failed to load settings: ' + error.message, 'error');
    }
  }
  
  bindEvents() {
    // Profile form submission with multiple handlers
    if (this.profileForm) {
      this.profileForm.addEventListener('submit', (e) => {
        e.preventDefault();
        console.log('💾 Profile form submitted via form event');
        this.saveProfile();
      });
      
      // Also handle direct button clicks
      const profileSaveBtn = this.profileForm.querySelector('button[type="submit"], .btn-primary');
      if (profileSaveBtn) {
        profileSaveBtn.addEventListener('click', (e) => {
          e.preventDefault();
          e.stopPropagation();
          console.log('💾 Profile save button clicked directly');
          this.saveProfile();
        });
      }
    }
    
    // AI form submission with multiple handlers
    if (this.aiForm) {
      this.aiForm.addEventListener('submit', (e) => {
        e.preventDefault();
        console.log('🤖 AI form submitted via form event');
        this.saveAISettings();
      });
      
      // Also handle direct button clicks
      const aiSaveBtn = this.aiForm.querySelector('button[type="submit"], .btn-primary');
      if (aiSaveBtn && aiSaveBtn !== this.testConnectionBtn) {
        aiSaveBtn.addEventListener('click', (e) => {
          e.preventDefault();
          e.stopPropagation();
          console.log('🤖 AI save button clicked directly');
          this.saveAISettings();
        });
      }
    }
    
    // Provider selection change
    if (this.aiProviderField) {
      this.aiProviderField.addEventListener('change', () => {
        console.log('🔄 Provider changed to:', this.aiProviderField.value);
        this.updateProviderVisibility();
      });
    }
    
    // Test connection
    if (this.testConnectionBtn) {
      this.testConnectionBtn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        console.log('🧪 Test connection clicked');
        this.testAIConnection();
      });
    }
    
    // Debug logging for form interactions
    if (this.aiEnabledField) {
      this.aiEnabledField.addEventListener('change', () => {
        console.log('🎛️ AI enabled changed to:', this.aiEnabledField.checked);
      });
    }
    
    // Log profile field changes
    [this.nameField, this.emailField, this.phoneField].forEach(field => {
      if (field) {
        field.addEventListener('input', () => {
          console.log(`📝 ${field.id} updated:`, field.value ? 'SET' : 'EMPTY');
        });
      }
    });
  }
  
  updateProviderVisibility() {
    if (!this.aiProviderField) return;
    
    const provider = this.aiProviderField.value;
    console.log('👁️ Updating visibility for provider:', provider);
    
    // Hide all provider settings
    const providers = ['groq', 'gemini', 'openai'];
    providers.forEach(p => {
      const element = document.getElementById(`${p}Settings`);
      if (element) {
        element.style.display = p === provider ? 'block' : 'none';
      }
    });
  }
  
  async saveProfile() {
    try {
      console.log('💾 Starting profile save...');
      
      // Gather profile data with validation
      const profile = {
        name: this.nameField ? this.nameField.value.trim() : '',
        email: this.emailField ? this.emailField.value.trim() : '',
        phone: this.phoneField ? this.phoneField.value.trim() : '',
        address: this.addressField ? this.addressField.value.trim() : '',
        company: this.companyField ? this.companyField.value.trim() : '',
        position: this.positionField ? this.positionField.value.trim() : '',
        linkedin: this.linkedinField ? this.linkedinField.value.trim() : ''
      };
      
      console.log('📤 Profile data to save:', profile);
      
      // Validate that we have at least some data
      const hasData = Object.values(profile).some(value => value.length > 0);
      if (!hasData) {
        throw new Error('Please fill in at least one field');
      }
      
      // Save to storage with explicit key
      await this.setStorageData('userProfile', profile);
      console.log('💾 Profile saved to storage');
      
      // Verify it was saved correctly
      const verification = await this.getStorageData('userProfile');
      console.log('✅ Profile save verification:', verification);
      
      // Check if verification matches what we saved
      const savedProfile = verification.userProfile || verification;
      const savedCorrectly = savedProfile.name === profile.name && savedProfile.email === profile.email;
      
      if (savedCorrectly) {
        this.showStatus('✅ Profile saved successfully! 👤', 'success');
      } else {
        console.warn('⚠️ Profile save verification failed:', { expected: profile, actual: savedProfile });
        this.showStatus('⚠️ Profile may not have saved correctly', 'error');
      }
      
    } catch (error) {
      console.error('❌ Failed to save profile:', error);
      this.showStatus('❌ Failed to save profile: ' + error.message, 'error');
    }
  }
  
  async saveAISettings() {
    try {
      console.log('🤖 Starting AI settings save...');
      
      const aiSettings = {
        enabled: this.aiEnabledField ? this.aiEnabledField.checked : false,
        provider: this.aiProviderField ? this.aiProviderField.value : 'groq',
        groqKey: this.groqKeyField ? this.groqKeyField.value.trim() : '',
        geminiKey: this.geminiKeyField ? this.geminiKeyField.value.trim() : '',
        openaiKey: this.openaiKeyField ? this.openaiKeyField.value.trim() : ''
      };
      
      console.log('📤 AI settings to save:', {
        enabled: aiSettings.enabled,
        provider: aiSettings.provider,
        groqKey: aiSettings.groqKey ? 'SET' : 'EMPTY',
        geminiKey: aiSettings.geminiKey ? 'SET' : 'EMPTY'
      });
      
      // Save to storage
      await this.setStorageData('aiSettings', aiSettings);
      console.log('💾 AI settings saved to storage');
      
      // Verify it was saved
      const verification = await this.getStorageData('aiSettings');
      console.log('✅ AI settings save verification:', verification);
      
      this.showStatus('✅ AI settings saved successfully! 🤖', 'success');
      
    } catch (error) {
      console.error('❌ Failed to save AI settings:', error);
      this.showStatus('❌ Failed to save AI settings: ' + error.message, 'error');
    }
  }
  
  async testAIConnection() {
    if (!this.aiProviderField) {
      this.showStatus('❌ Provider field not found', 'error');
      return;
    }
    
    const provider = this.aiProviderField.value;
    
    console.log(`🧪 Testing ${provider} connection...`);
    
    let apiKey = '';
    switch (provider) {
      case 'groq':
        apiKey = this.groqKeyField ? this.groqKeyField.value.trim() : '';
        break;
      case 'gemini':
        apiKey = this.geminiKeyField ? this.geminiKeyField.value.trim() : '';
        break;
      case 'openai':
        apiKey = this.openaiKeyField ? this.openaiKeyField.value.trim() : '';
        break;
    }
    
    console.log(`🔑 API key for ${provider}:`, apiKey ? 'PROVIDED' : 'MISSING');
    
    if (!apiKey) {
      this.showStatus('❌ Please enter an API key first', 'error');
      return;
    }
    
    this.testConnectionBtn.textContent = 'Testing...';
    this.testConnectionBtn.disabled = true;
    
    try {
      const result = await this.testConnection(provider, apiKey);
      console.log('✅ Connection test successful:', result);
      this.showStatus(`✅ ${result}`, 'success');
      
    } catch (error) {
      console.error('❌ Connection test failed:', error);
      this.showStatus(`❌ ${error.message}`, 'error');
    } finally {
      this.testConnectionBtn.textContent = 'Test Connection';
      this.testConnectionBtn.disabled = false;
    }
  }
  
  async testConnection(provider, apiKey) {
    switch (provider) {
      case 'groq':
        return await this.testGroq(apiKey);
      case 'gemini':
        return await this.testGemini(apiKey);
      case 'openai':
        return await this.testOpenAI(apiKey);
      default:
        throw new Error('Unknown provider');
    }
  }
  
  async testGroq(apiKey) {
    console.log('🚀 Testing Groq connection...');
    
    const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`
      },
      body: JSON.stringify({
        model: 'llama-3.1-8b-instant',
        messages: [
          {
            role: 'user',
            content: 'Respond with exactly: "Groq connection successful"'
          }
        ],
        max_tokens: 50,
        temperature: 0
      })
    });
    
    console.log('🌐 Groq response status:', response.status);
    
    if (!response.ok) {
      const error = await response.json();
      console.error('❌ Groq API error:', error);
      throw new Error(error.error?.message || `HTTP ${response.status}`);
    }
    
    const data = await response.json();
    const message = data.choices[0].message.content;
    
    console.log('🎯 Groq test response:', message);
    return 'Groq connection successful! 🚀 Model: llama-3.1-8b-instant';
  }
  
  async testGemini(apiKey) {
    console.log('🎯 Testing Gemini connection...');
    
    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=${apiKey}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        contents: [{
          parts: [{
            text: 'Respond with exactly: "Gemini connection successful"'
          }]
        }],
        generationConfig: {
          temperature: 0,
          maxOutputTokens: 50
        }
      })
    });
    
    console.log('🌐 Gemini response status:', response.status);
    
    if (!response.ok) {
      const error = await response.json();
      console.error('❌ Gemini API error:', error);
      throw new Error(error.error?.message || `HTTP ${response.status}`);
    }
    
    const data = await response.json();
    
    if (!data.candidates || data.candidates.length === 0) {
      throw new Error('No response from Gemini');
    }
    
    const message = data.candidates[0].content.parts[0].text;
    console.log('🎯 Gemini test response:', message);
    
    return 'Gemini connection successful! 🎯';
  }
  
  async testOpenAI(apiKey) {
    console.log('💰 Testing OpenAI connection...');
    
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`
      },
      body: JSON.stringify({
        model: 'gpt-3.5-turbo',
        messages: [
          {
            role: 'user',
            content: 'Respond with exactly: "OpenAI connection successful"'
          }
        ],
        max_tokens: 50,
        temperature: 0
      })
    });
    
    console.log('🌐 OpenAI response status:', response.status);
    
    if (!response.ok) {
      const error = await response.json();
      console.error('❌ OpenAI API error:', error);
      throw new Error(error.error?.message || `HTTP ${response.status}`);
    }
    
    const data = await response.json();
    const message = data.choices[0].message.content;
    
    console.log('💰 OpenAI test response:', message);
    return 'OpenAI connection successful! 💰';
  }
  
  // Storage helper methods
  setStorageData(key, value) {
    return new Promise((resolve, reject) => {
      chrome.storage.local.set({ [key]: value }, () => {
        if (chrome.runtime.lastError) {
          console.error('Storage set error:', chrome.runtime.lastError);
          reject(new Error(chrome.runtime.lastError.message));
        } else {
          console.log(`💾 Storage set successful for key: ${key}`);
          resolve();
        }
      });
    });
  }
  
  getStorageData(key) {
    return new Promise((resolve) => {
      chrome.storage.local.get(key, (data) => {
        if (chrome.runtime.lastError) {
          console.error('Storage get error:', chrome.runtime.lastError);
          resolve({});
        } else {
          console.log(`📥 Storage get successful for key: ${key}`, data);
          resolve(data);
        }
      });
    });
  }
  
  showStatus(message, type = 'info') {
  console.log(`📢 Status: ${message} (${type})`);
  
    if (this.status) {
      this.status.textContent = message;
      this.status.className = `toast ${type}`;
      this.status.style.display = 'block';
      
      // Auto-hide after 3 seconds
      setTimeout(() => {
        this.status.style.display = 'none';
      }, 3000);
    }
  }
}