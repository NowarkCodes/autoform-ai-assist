// popup.js - Debug version with detailed AI status
document.addEventListener('DOMContentLoaded', async () => {
  console.log('🎯 Popup loaded');
  const popup = new PopupController();
  await popup.init();
});

class PopupController {
  constructor() {
    this.profileStatus = document.getElementById('profileStatus');
    this.aiStatus = document.getElementById('aiStatus');
    this.fillCurrentFormBtn = document.getElementById('fillCurrentForm');
    this.openOptionsBtn = document.getElementById('openOptions');
    this.detectFormsBtn = document.getElementById('detectForms');
    this.clearAllFieldsBtn = document.getElementById('clearAllFields');
  }
  
  async init() {
    console.log('🚀 Initializing popup controller');
    await this.updateStatus();
    this.bindEvents();
    await this.updateFormCount();
  }
  
  async updateStatus() {
    try {
      console.log('📊 Updating popup status...');
      
      // Check profile status
      const profileData = await this.getStorageData('userProfile');
      const profile = profileData.userProfile || profileData || {};
      
      console.log('👤 Profile data:', profile);
      
      const hasProfile = profile.name || profile.email || profile.phone;
      this.profileStatus.textContent = hasProfile ? 'Configured' : 'Not set';
      this.profileStatus.className = hasProfile ? 'status-value success' : 'status-value error';
      
      // Check AI status with detailed debugging
      const aiData = await this.getStorageData('aiSettings');
      const aiSettings = aiData.aiSettings || aiData || {};
      
      console.log('🤖 AI settings in popup:', aiSettings);
      
      // Determine AI status
      const isEnabled = aiSettings.enabled === true;
      const hasValidKey = this.checkValidKey(aiSettings);
      
      console.log('🔍 AI status check:', {
        enabled: isEnabled,
        provider: aiSettings.provider,
        hasValidKey: hasValidKey,
        keys: {
          groq: aiSettings.groqKey ? 'SET' : 'EMPTY',
          gemini: aiSettings.geminiKey ? 'SET' : 'EMPTY',
          openai: aiSettings.openaiKey ? 'SET' : 'EMPTY'
        }
      });
      
      if (isEnabled && hasValidKey) {
        this.aiStatus.textContent = `Active (${aiSettings.provider || 'unknown'})`;
        this.aiStatus.className = 'status-value success';
      } else if (isEnabled && !hasValidKey) {
        this.aiStatus.textContent = 'No API Key';
        this.aiStatus.className = 'status-value error';
      } else {
        this.aiStatus.textContent = 'Disabled';
        this.aiStatus.className = 'status-value error';
      }
      
    } catch (error) {
      console.error('❌ Failed to update status:', error);
      this.showNotification('Failed to load extension status', 'error');
    }
  }
  
  checkValidKey(aiSettings) {
    const provider = aiSettings.provider || 'groq';
    
    switch (provider) {
      case 'groq':
        return !!(aiSettings.groqKey && aiSettings.groqKey.trim());
      case 'gemini':
        return !!(aiSettings.geminiKey && aiSettings.geminiKey.trim());
      case 'openai':
        return !!(aiSettings.openaiKey && aiSettings.openaiKey.trim());
      default:
        return false;
    }
  }
  
  bindEvents() {
    this.fillCurrentFormBtn.addEventListener('click', async () => {
      console.log('🖱️ Fill Current Form clicked');
      await this.fillCurrentForm();
    });
    
    this.openOptionsBtn.addEventListener('click', () => {
      console.log('⚙️ Opening options page');
      chrome.runtime.openOptionsPage();
      window.close();
    });
    
    this.detectFormsBtn.addEventListener('click', async () => {
      console.log('🔍 Detect forms clicked');
      await this.updateFormCount();
    });
    
    this.clearAllFieldsBtn.addEventListener('click', async () => {
      console.log('🗑️ Clear all fields clicked');
      await this.clearAllFields();
    });
    
    // Add debug button for testing
    this.addDebugButton();
  }
  
  addDebugButton() {
    const debugBtn = document.createElement('button');
    debugBtn.innerHTML = '<span class="btn-icon-small">🔧</span><span class="btn-text-small">Debug AI</span>';
    debugBtn.className = 'btn btn-small';
    debugBtn.style.cssText = `
      background: #fff3e0;
      color: #f57c00;
      border: 2px solid #ffe0b2;
      margin-top: 8px;
    `;
    debugBtn.addEventListener('click', async () => {
      await this.debugAI();
    });
    
    document.querySelector('.quick-actions').appendChild(debugBtn);
  }
  
  async debugAI() {
    console.log('🔧 Starting AI debug...');
    
    try {
      // Test AI suggestion directly
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      
      const response = await this.sendMessageToBackground({
        action: 'generateAISuggestion',
        fieldType: 'bio',
        context: 'Debug test from popup'
      });
      
      console.log('🎯 AI debug response:', response);
      
      if (response.suggestion) {
        this.showNotification(`AI Test: "${response.suggestion.substring(0, 50)}..."`, 'success');
      } else if (response.error) {
        this.showNotification(`AI Error: ${response.error}`, 'error');
      } else {
        this.showNotification('AI returned empty response', 'error');
      }
      
    } catch (error) {
      console.error('❌ AI debug failed:', error);
      this.showNotification(`AI Debug Failed: ${error.message}`, 'error');
    }
  }
  
  async fillCurrentForm() {
    try {
      const btnText = this.fillCurrentFormBtn.querySelector('.btn-text');
      const btnIcon = this.fillCurrentFormBtn.querySelector('.btn-icon');
      btnText.textContent = 'Filling...';
      btnIcon.textContent = '⏳';
      this.fillCurrentFormBtn.disabled = true;
      
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      console.log('📍 Current tab:', tab.url);
      
      if (tab.url.startsWith('chrome://') || tab.url.startsWith('chrome-extension://')) {
        throw new Error('Cannot access Chrome internal pages');
      }
      
      const response = await this.sendMessageToTab(tab.id, {
        action: 'fillAllForms'
      });
      
      console.log('✅ Fill response:', response);
      
      if (response && response.success) {
        this.showNotification(`✨ Filled ${response.result?.filled || 0} fields!`, 'success');
        btnIcon.textContent = '✅';
        setTimeout(() => {
          btnIcon.textContent = '✨';
        }, 2000);
      } else {
        throw new Error(response?.error || 'Unknown error');
      }
      
    } catch (error) {
      console.error('❌ Failed to fill forms:', error);
      this.showNotification(`Failed: ${error.message}`, 'error');
    } finally {
      const btnText = this.fillCurrentFormBtn.querySelector('.btn-text');
      btnText.textContent = 'Fill Current Form';
      this.fillCurrentFormBtn.disabled = false;
    }
  }
  
  async updateFormCount() {
    try {
      const btnText = this.detectFormsBtn.querySelector('.btn-text-small');
      const originalText = btnText.textContent;
      btnText.textContent = 'Scanning...';
      
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      
      if (tab.url.startsWith('chrome://') || tab.url.startsWith('chrome-extension://')) {
        btnText.textContent = 'Forms (0)';
        return;
      }
      
      const response = await this.sendMessageToTab(tab.id, {
        action: 'countForms'
      });
      
      console.log('📊 Form count response:', response);
      
      const count = response?.count || 0;
      btnText.textContent = `Forms (${count})`;
      
      // Add a subtle animation
      this.detectFormsBtn.style.animation = 'pulse 0.5s ease';
      setTimeout(() => {
        this.detectFormsBtn.style.animation = '';
      }, 500);
      
    } catch (error) {
      console.error('⚠️ Failed to count forms:', error);
      const btnText = this.detectFormsBtn.querySelector('.btn-text-small');
      btnText.textContent = 'Forms (?)';
    }
  }
  
  async clearAllFields() {
    try {
      if (!confirm('Clear all form fields on this page?')) {
        return;
      }
      
      const btnText = this.clearAllFieldsBtn.querySelector('.btn-text-small');
      const btnIcon = this.clearAllFieldsBtn.querySelector('.btn-icon-small');
      btnText.textContent = 'Clearing...';
      btnIcon.textContent = '⏳';
      this.clearAllFieldsBtn.disabled = true;
      
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      
      const response = await this.sendMessageToTab(tab.id, {
        action: 'clearAllFields'
      });
      
      console.log('🗑️ Clear response:', response);
      
      if (response && response.success) {
        this.showNotification(`🗑️ Cleared ${response.result?.cleared || 0} fields!`, 'success');
      } else {
        throw new Error(response?.error || 'Unknown error');
      }
      
    } catch (error) {
      console.error('❌ Failed to clear fields:', error);
      this.showNotification(`Failed: ${error.message}`, 'error');
    } finally {
      const btnText = this.clearAllFieldsBtn.querySelector('.btn-text-small');
      const btnIcon = this.clearAllFieldsBtn.querySelector('.btn-icon-small');
      btnText.textContent = 'Clear All';
      btnIcon.textContent = '🗑️';
      this.clearAllFieldsBtn.disabled = false;
    }
  }
  
  async sendMessageToTab(tabId, message) {
    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        reject(new Error('Message timeout - content script may not be loaded'));
      }, 5000);
      
      chrome.tabs.sendMessage(tabId, message, (response) => {
        clearTimeout(timeout);
        
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
        } else {
          resolve(response);
        }
      });
    });
  }
  
  async sendMessageToBackground(message) {
    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        reject(new Error('Background message timeout'));
      }, 10000); // Longer timeout for AI requests
      
      chrome.runtime.sendMessage(message, (response) => {
        clearTimeout(timeout);
        
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
        } else {
          resolve(response || {});
        }
      });
    });
  }
  
  getStorageData(key) {
    return new Promise((resolve) => {
      chrome.storage.local.get(key, (data) => {
        if (chrome.runtime.lastError) {
          console.error('Storage error:', chrome.runtime.lastError);
          resolve({});
        } else {
          resolve(data);
        }
      });
    });
  }
  
  showNotification(message, type = 'info') {
    console.log(`📢 Notification: ${message} (${type})`);
    
    // Remove existing notifications
    const existing = document.querySelectorAll('.notification');
    existing.forEach(n => n.remove());
    
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    
    const colors = {
      success: '#137333',
      error: '#d93025',
      info: '#1a73e8'
    };
    
    notification.style.cssText = `
      position: fixed;
      top: 10px;
      left: 10px;
      right: 10px;
      background: ${colors[type] || colors.info};
      color: white;
      padding: 12px 16px;
      border-radius: 10px;
      font-size: 13px;
      font-weight: 600;
      z-index: 10000;
      box-shadow: 0 4px 12px rgba(0,0,0,0.3);
      word-break: break-word;
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
      notification.style.animation = 'slideInNotification 0.3s ease-out reverse';
      setTimeout(() => {
        notification.remove();
      }, 300);
    }, 3700);
  }
}