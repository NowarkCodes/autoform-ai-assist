// background.js - Fixed profile retrieval
console.log('🤖 Auto Form Filler background script - FIXED PROFILE VERSION');

// Handle extension installation
chrome.runtime.onInstalled.addListener(() => {
  console.log('🎯 Auto Form Filler installed');
  
  // Set default storage values
  chrome.storage.local.set({
    userProfile: {
      name: '',
      email: '',
      phone: '',
      address: '',
      company: '',
      position: '',
      linkedin: ''
    },
    aiSettings: {
      enabled: false,
      provider: 'groq',
      groqKey: '',
      geminiKey: '',
      openaiKey: ''
    }
  });
});

// Listen for messages - FIXED PROFILE HANDLING
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('📨 Background received message:', request.action);
  
  if (request.action === 'getProfile') {
    console.log('👤 Getting profile data...');
    
    chrome.storage.local.get(['userProfile'], (data) => {
      if (chrome.runtime.lastError) {
        console.error('❌ Storage error:', chrome.runtime.lastError);
        sendResponse({});
        return;
      }
      
      console.log('📦 Raw storage data:', data);
      
      // Handle different storage formats
      let profile = {};
      
      if (data && data.userProfile) {
        profile = data.userProfile;
        console.log('✅ Found userProfile key:', profile);
      } else if (data && typeof data === 'object') {
        // Check if data itself contains profile fields
        const hasProfileFields = data.name || data.email || data.phone || data.company;
        if (hasProfileFields) {
          profile = data;
          console.log('✅ Found profile in root data:', profile);
        }
      }
      
      console.log('👤 Sending profile to content script:', profile);
      sendResponse(profile);
    });
    
    return true; // Keep message channel open
  }
  
  if (request.action === 'generateAISuggestion') {
    console.log('🤖 Generating AI suggestion for:', request.fieldType);
    
    generateAISuggestion(request.fieldType, request.context)
      .then(suggestion => {
        console.log('✅ AI suggestion generated');
        sendResponse({ suggestion });
      })
      .catch(error => {
        console.error('❌ AI suggestion error:', error);
        sendResponse({ error: error.message });
      });
    return true;
  }
  
  // Debug action to check storage
  if (request.action === 'debugStorage') {
    chrome.storage.local.get(null, (allData) => {
      console.log('🔍 ALL STORAGE DATA:', allData);
      sendResponse(allData);
    });
    return true;
  }
});

async function generateAISuggestion(fieldType, context) {
  try {
    const settings = await getStorageData('aiSettings');
    const aiSettings = settings.aiSettings || settings || {};
    
    if (!aiSettings.enabled) {
      throw new Error('AI suggestions are disabled');
    }
    
    const provider = aiSettings.provider || 'groq';
    let apiKey = '';
    
    switch (provider) {
      case 'groq':
        apiKey = aiSettings.groqKey;
        break;
      case 'gemini':
        apiKey = aiSettings.geminiKey;
        break;
      case 'openai':
        apiKey = aiSettings.openaiKey;
        break;
      default:
        throw new Error(`Unknown AI provider: ${provider}`);
    }
    
    if (!apiKey) {
      throw new Error(`${provider} API key not configured`);
    }
    
    console.log(`🤖 Using ${provider} for ${fieldType}`);
    
    switch (provider) {
      case 'groq':
        return await generateGroqSuggestion(apiKey, fieldType, context);
      case 'gemini':
        return await generateGeminiSuggestion(apiKey, fieldType, context);
      case 'openai':
        return await generateOpenAISuggestion(apiKey, fieldType, context);
      default:
        throw new Error('Invalid provider');
    }
    
  } catch (error) {
    console.error('❌ AI generation failed:', error);
    throw error;
  }
}

async function generateGroqSuggestion(apiKey, fieldType, context) {
  const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${apiKey}`
    },
    body: JSON.stringify({
      model: 'llama-3.1-8b-instant',
      messages: [
        {
          role: 'system',
          content: getSystemPrompt()
        },
        {
          role: 'user',
          content: createPrompt(fieldType, context)
        }
      ],
      max_tokens: 150,
      temperature: 0.7,
      stream: false
    })
  });
  
  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.error?.message || `Groq API error: ${response.status}`);
  }
  
  const data = await response.json();
  return data.choices[0].message.content.trim();
}

async function generateGeminiSuggestion(apiKey, fieldType, context) {
  const prompt = getSystemPrompt() + '\n\n' + createPrompt(fieldType, context);
  
  const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=${apiKey}`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      contents: [{
        parts: [{
          text: prompt
        }]
      }],
      generationConfig: {
        temperature: 0.7,
        topK: 40,
        topP: 0.95,
        maxOutputTokens: 150,
      }
    })
  });
  
  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.error?.message || `Gemini API error: ${response.status}`);
  }
  
  const data = await response.json();
  
  if (!data.candidates || data.candidates.length === 0) {
    throw new Error('No response from Gemini');
  }
  
  const content = data.candidates[0].content;
  if (!content || !content.parts || content.parts.length === 0) {
    throw new Error('Empty response from Gemini');
  }
  
  return content.parts[0].text.trim();
}

async function generateOpenAISuggestion(apiKey, fieldType, context) {
  const response = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${apiKey}`
    },
    body: JSON.stringify({
      model: 'gpt-3.5-turbo',
      messages: [
        {
          role: 'system',
          content: getSystemPrompt()
        },
        {
          role: 'user',
          content: createPrompt(fieldType, context)
        }
      ],
      max_tokens: 150,
      temperature: 0.7
    })
  });
  
  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.error?.message || `OpenAI API error: ${response.status}`);
  }
  
  const data = await response.json();
  return data.choices[0].message.content.trim();
}

function getSystemPrompt() {
  return `You are a professional writing assistant that generates appropriate content for web form fields.

Key guidelines:
- Write in a professional, polite tone
- Keep responses concise and relevant
- For bio/about fields: 2-3 sentences, 50-80 words
- For message/comment fields: Brief and courteous, 20-40 words  
- For reason/motivation fields: Professional explanations, 20-50 words
- Avoid overly personal details or controversial topics
- Make content sound natural and human-like
- Generate content suitable for professional/business contexts`;
}

function createPrompt(fieldType, context) {
  const prompts = {
    bio: `Write a professional bio or "about me" section (60-80 words). Make it engaging but generic enough to be widely applicable. Context: ${context}`,
    message: `Write a brief, professional message or comment (25-40 words). Keep it polite and appropriate. Context: ${context}`,
    reason: `Write a professional reason or explanation (25-50 words). Make it realistic and appropriate. Context: ${context}`,
    description: `Write a brief, professional description (40-60 words). Keep it relevant and engaging. Context: ${context}`,
    experience: `Write a brief experience summary (50-70 words). Keep it professional. Context: ${context}`,
    general: `Write appropriate professional content for this form field (30-60 words). Field type: ${fieldType}, Context: ${context}`
  };
  
  return prompts[fieldType] || prompts.general;
}

function getStorageData(key) {
  return new Promise((resolve) => {
    chrome.storage.local.get(key, (data) => {
      if (chrome.runtime.lastError) {
        console.error('Storage error:', chrome.runtime.lastError);
        resolve({});
      } else {
        resolve(data);
      }
    });
  });
}