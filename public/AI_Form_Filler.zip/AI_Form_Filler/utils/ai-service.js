// utils/ai-service.js - Updated with profile context support
class AIService {
  constructor() {
    this.providers = {
      openai: {
        name: 'OpenAI',
        baseUrl: 'https://api.openai.com/v1/chat/completions',
        model: 'gpt-3.5-turbo'
      },
      gemini: {
        name: 'Google Gemini',
        baseUrl: 'https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent',
        model: 'gemini-pro'
      },
      groq: {
        name: 'Groq',
        baseUrl: 'https://api.groq.com/openai/v1/chat/completions',
        model: 'llama3-8b-8192'
      }
    };
  }
  
  async getAISettings() {
    const aiSettings = await StorageManager.get('aiSettings');
    return aiSettings || {
      enabled: false,
      provider: 'groq',
      openaiKey: '',
      geminiKey: '',
      groqKey: ''
    };
  }
  
  // NEW: Get user profile for context
  async getUserProfile() {
    return new Promise((resolve) => {
      chrome.storage.local.get('userProfile', (data) => {
        if (chrome.runtime.lastError) {
          console.error('Failed to get user profile:', chrome.runtime.lastError);
          resolve({});
        } else {
          const profile = data.userProfile || {};
          console.log('📋 User profile loaded for AI context:', profile);
          resolve(profile);
        }
      });
    });
  }
  
  async isEnabled() {
    const settings = await this.getAISettings();
    const hasKey = this.hasValidKey(settings);
    return settings.enabled && hasKey;
  }
  
  hasValidKey(settings) {
    switch (settings.provider) {
      case 'openai': return !!settings.openaiKey;
      case 'gemini': return !!settings.geminiKey;
      case 'groq': return !!settings.groqKey;
      default: return false;
    }
  }
  
  // UPDATED: Now fetches user profile automatically
  async generateSuggestion(fieldType, context = '') {
    if (!await this.isEnabled()) {
      throw new Error('AI service is not enabled or configured');
    }
    
    const settings = await this.getAISettings();
    const provider = this.providers[settings.provider];
    
    if (!provider) {
      throw new Error(`Unknown AI provider: ${settings.provider}`);
    }
    
    // Fetch user profile for personalized context
    const userProfile = await this.getUserProfile();
    
    console.log(`🤖 Using ${provider.name} for ${fieldType} suggestion with user context`);
    
    try {
      switch (settings.provider) {
        case 'openai':
          return await this.generateOpenAI(settings, fieldType, context, userProfile);
        case 'gemini':
          return await this.generateGemini(settings, fieldType, context, userProfile);
        case 'groq':
          return await this.generateGroq(settings, fieldType, context, userProfile);
        default:
          throw new Error('Invalid provider');
      }
    } catch (error) {
      console.error(`❌ ${provider.name} API error:`, error);
      throw new Error(`${provider.name} API error: ${error.message}`);
    }
  }
  
  // UPDATED: Added userProfile parameter
  async generateOpenAI(settings, fieldType, context, userProfile) {
    const response = await fetch(this.providers.openai.baseUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${settings.openaiKey}`
      },
      body: JSON.stringify({
        model: this.providers.openai.model,
        messages: [
          {
            role: 'system',
            content: this.getSystemPrompt(userProfile)
          },
          {
            role: 'user',
            content: this.createPrompt(fieldType, context, userProfile)
          }
        ],
        max_tokens: 150,
        temperature: 0.7
      })
    });
    
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error?.message || `HTTP ${response.status}`);
    }
    
    const data = await response.json();
    return data.choices[0].message.content.trim();
  }
  
  // UPDATED: Added userProfile parameter
  async generateGemini(settings, fieldType, context, userProfile) {
    const prompt = this.getSystemPrompt(userProfile) + '\n\n' + this.createPrompt(fieldType, context, userProfile);
    
    const response = await fetch(`${this.providers.gemini.baseUrl}?key=${settings.geminiKey}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        contents: [{
          parts: [{
            text: prompt
          }]
        }],
        generationConfig: {
          temperature: 0.7,
          topK: 40,
          topP: 0.95,
          maxOutputTokens: 150,
        }
      })
    });
    
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error?.message || `HTTP ${response.status}`);
    }
    
    const data = await response.json();
    
    if (!data.candidates || data.candidates.length === 0) {
      throw new Error('No response generated');
    }
    
    const content = data.candidates[0].content;
    if (!content || !content.parts || content.parts.length === 0) {
      throw new Error('Empty response from Gemini');
    }
    
    return content.parts[0].text.trim();
  }
  
  // UPDATED: Added userProfile parameter
  async generateGroq(settings, fieldType, context, userProfile) {
    const response = await fetch(this.providers.groq.baseUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${settings.groqKey}`
      },
      body: JSON.stringify({
        model: this.providers.groq.model,
        messages: [
          {
            role: 'system',
            content: this.getSystemPrompt(userProfile)
          },
          {
            role: 'user',
            content: this.createPrompt(fieldType, context, userProfile)
          }
        ],
        max_tokens: 150,
        temperature: 0.7,
        stream: false
      })
    });
    
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error?.message || `HTTP ${response.status}`);
    }
    
    const data = await response.json();
    return data.choices[0].message.content.trim();
  }
  
  // UPDATED: Now accepts and uses userProfile
  getSystemPrompt(userProfile = {}) {
    let systemPrompt = `You are a helpful AI assistant that generates appropriate, professional content for web form fields.`;
    
    // Add user context if available
    if (userProfile.name || userProfile.position || userProfile.company) {
      systemPrompt += `\n\nUser Profile Information:`;
      
      if (userProfile.name) {
        systemPrompt += `\n- Name: ${userProfile.name}`;
      }
      if (userProfile.position) {
        systemPrompt += `\n- Position/Role: ${userProfile.position}`;
      }
      if (userProfile.company) {
        systemPrompt += `\n- Company: ${userProfile.company}`;
      }
      if (userProfile.linkedin) {
        systemPrompt += `\n- LinkedIn: ${userProfile.linkedin}`;
      }
      
      systemPrompt += `\n\nIMPORTANT: Use this profile information to personalize your responses. For example, if the user is a "Red Teamer", generate content relevant to cybersecurity and penetration testing.`;
    }
    
    systemPrompt += `\n\nRules:
- Keep responses concise and relevant
- Use professional, polite language
- Tailor content based on the user's profile (position, role, expertise)
- For bio fields: 2-3 sentences max, personalized to their role
- For message fields: Be brief and courteous
- For reason fields: Provide realistic, professional reasons based on their background
- Avoid generic content - make it specific to the user's profile
- Generate content that sounds natural and human-like`;
    
    return systemPrompt;
  }
  
  // UPDATED: Now accepts and uses userProfile
  createPrompt(fieldType, context, userProfile = {}) {
    const userContext = this.buildUserContext(userProfile);
    
    const prompts = {
      bio: `Generate a professional bio/about section (50-80 words).${userContext} Make it engaging and specific to their expertise. Context: ${context}`,
      
      message: `Generate a brief, professional message or comment (20-40 words).${userContext} Keep it polite and relevant to their role. Context: ${context}`,
      
      reason: `Generate a professional reason or explanation (20-50 words).${userContext} Make it realistic and appropriate for their background. Context: ${context}`,
      
      description: `Generate a brief, professional description (30-60 words).${userContext} Context: ${context}`,
      
      motivation: `Generate a brief motivation statement (30-50 words).${userContext} Make it authentic to their career path. Context: ${context}`,
      
      experience: `Generate a brief experience summary (40-70 words).${userContext} Focus on their expertise area. Context: ${context}`,
      
      objective: `Generate a brief objective or goal statement (20-40 words).${userContext} Align with their professional role. Context: ${context}`,
      
      cover_letter: `Generate a brief cover letter excerpt (50-80 words).${userContext} Make it engaging and role-specific. Context: ${context}`,
      
      general: `Generate appropriate professional content for this form field (20-60 words).${userContext} Context: ${context}, Field type: ${fieldType}`
    };
    
    return prompts[fieldType] || prompts.general;
  }
  
  // NEW: Build user context string
  buildUserContext(userProfile) {
    if (!userProfile || Object.keys(userProfile).length === 0) {
      return '';
    }
    
    let context = '';
    
    if (userProfile.position) {
      context += ` The user is a ${userProfile.position}.`;
    }
    
    if (userProfile.company) {
      context += ` They work at ${userProfile.company}.`;
    }
    
    if (userProfile.name) {
      context += ` User's name: ${userProfile.name}.`;
    }
    
    return context;
  }
  
  // Test connection methods remain the same
  async testConnection(provider, apiKey) {
    try {
      switch (provider) {
        case 'openai':
          return await this.testOpenAI(apiKey);
        case 'gemini':
          return await this.testGemini(apiKey);
        case 'groq':
          return await this.testGroq(apiKey);
        default:
          throw new Error('Unknown provider');
      }
    } catch (error) {
      throw new Error(`Connection test failed: ${error.message}`);
    }
  }
  
  async testOpenAI(apiKey) {
    const response = await fetch('https://api.openai.com/v1/models', {
      headers: { 'Authorization': `Bearer ${apiKey}` }
    });
    
    if (!response.ok) {
      throw new Error('Invalid API key or quota exceeded');
    }
    
    return 'OpenAI connection successful';
  }
  
  async testGemini(apiKey) {
    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=${apiKey}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{ parts: [{ text: 'Hello' }] }]
      })
    });
    
    if (!response.ok) {
      throw new Error('Invalid API key or quota exceeded');
    }
    
    return 'Gemini connection successful';
  }
  
  async testGroq(apiKey) {
    const response = await fetch('https://api.groq.com/openai/v1/models', {
      headers: { 'Authorization': `Bearer ${apiKey}` }
    });
    
    if (!response.ok) {
      throw new Error('Invalid API key or rate limit exceeded');
    }
    
    return 'Groq connection successful';
  }
}

// Make it available globally
if (typeof window !== 'undefined') {
  window.AIService = AIService;
}